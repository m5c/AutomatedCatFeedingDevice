"""
Represents a valid display content, that is to say something that can be statically displayed on
a 7 segment display with decimal dot, four digits.
Author: Maximilian Schiedermeier
"""
from display.segment_char import SegmentChar


class DisplayContent:

    def __init__(self, string_content: str) -> None:
        """
        Constructor to create a display content entity. Pass a string and the contructor tries to
        convert it to a display_content representation.
        This entity should be placed on the thread safe queue communicating with the display entity.
        """
        # TODO: convert to segment chars.
        self.__segment_chars = [SegmentChar.UNKNOWN, SegmentChar.UNKNOWN, SegmentChar.UNKNOWN,
                                SegmentChar.UNKNOWN]

    # TODO: Add smarter constructor that accepts strings (and internally converts them to
    #  SegmentChar List as good as possible, e.g. using underscore for everything undefined.)

    @property
    def segment_chars(self) -> list[SegmentChar]:
        """
        Python pseudo getter to access the actual content
        """
        return self.__segment_chars

    def get_segment_char_by_index(self, index: int) -> SegmentChar:
        """
        Similar to previous method, but returns only segment char at specific index.
        """
        return self.__segment_chars[index]
