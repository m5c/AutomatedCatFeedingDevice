from clock import Clock

clock: Clock = Clock(10, None)
clock.start_clock()